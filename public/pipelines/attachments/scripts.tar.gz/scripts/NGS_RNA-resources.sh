set -e 
set -u

module load NGS_RNA


DATADIR="$HOME/apps/data/"

### Getting Reference genome
printf "Getting Reference genome ..."

mkdir -p ${DATADIR}/1000G/phase1
cd ${DATADIR}/1000G/phase1

wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37.dict.gz
wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37.dict.gz.md5

wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37.fasta.fai.gz
wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37.fasta.fai.gz.md5

wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37.fasta.gz
wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37.fasta.gz.md5

wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37_decoy.dict.gz
wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37_decoy.dict.gz.md5

wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37_decoy.fasta.fai.gz
wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37_decoy.fasta.fai.gz.md5

wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37_decoy.fasta.gz
wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/human_g1k_v37_decoy.fasta.gz.md5

for i in $(ls ${DATADIR}/1000G/phase1/*.gz); do gzip -d $i ;done

## DbSNP
mkdir ${DATADIR}/dbSNP/
cd ${DATADIR}/dbSNP/
wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/dbsnp_138.b37.vcf.gz
wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/dbsnp_138.b37.vcf.gz.md5

wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/dbsnp_138.b37.vcf.idx.gz
wget ftp://gsapubftp-anonymous@ftp.broadinstitute.org/bundle/2.8/b37/dbsnp_138.b37.vcf.idx.gz.md5

#(create ths folder first)
mkdir -p ${DATADIR}/ftp.ensembl.org/pub/release-75/fasta/homo_sapiens

#download reference data
wget ftp.ensembl.org/pub/release-75/fasta/homo_sapiens/dna/homo_sapiens.GRCm37.dna.toplevel.fa.gz
wget ftp://ftp.ensembl.org/pub/release-75/gtf/homo_sapiens/homo_sapiens.GRCm37.75.gtf.gz

#unpack
gzip -d homo_sapiens.GRCm37.dna.toplevel.fa.gz
gzip -d homo_sapiens.GRCm37.75.gtf.gz


module load hisat/0.1.6-beta-goolf-1.7.20 
#generate INDEX

cd ${DATADIR}/ftp.ensembl.org/pub/release-75/fasta/homo_sapiens/
hisat-build homo_sapiens.GRCm37.dna.toplevel.fa homo_sapiens.GRCm37


#REFFLAT file was generated using
# 1. Download http://hgdownload.cse.ucsc.edu/admin/exe/linux.x86_64/gtfToGenePred
# 2. Convert a downloaded gtf annotation file into genepred extended format (tmp file)

cd ${DATADIR}/ftp.ensembl.org/pub/release-75/gtf/homo_sapiens/
./gtfToGenePred -genePredExt homo_sapiens.GRCm37.75.gtf tmp

# 3. Parse the tmp file into genepred format 
awk 'BEGIN{FS="\t"};{print $12"\t"$1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6"\t"$7"\t"$8"\t"$9"\t"$10}' tmp > homo_sapiens.GRCm37.75.gtf.annotation.refFlat


#annotation_geneid_v76.txt.gz was generate
export via http://www.ensembl.org/biomart/martview/ the following attributes:

#In this order!

Ensembl Gene ID 
Associated Gene Name    
Chromosome Name 
Gene Start (bp) 
Gene End (bp)

#unpack
gzip -d mart_export.txt.gz

#add annotion info to firts column
awk 'BEGIN{FS="\t"};{print "Ensembl_v.80\t"$1"\t"$2"\t"$3"\t"$4"\t"$5}' mart_export.txt >> homo_sapiens.GRCm37.75.annotation.geneIds.txt

# zip
gzip homo_sapiens.GRCm37.75.annotation.geneIds.txt

#Build Kallisto idx
module load kallisto
kallisto index --index=homo_sapiens.GRCm37.dna.toplevel.idx homo_sapiens.GRCm37.dna.toplevel.fa

#build .dict file
module load GATK

java -jar CreateSequenceDictionary.jar R= Homo_sapiens_assembly18.fasta O= Homo_sapiens_assembly18.dict

#generate rrna.interval_list
grep rRNA homo_sapiens.GRCm37.75.gtf | awk '{if($3 == "gene"){gsub("\"|;","",$10);print $1"\t"$4"\t"$5"\t"$7"\t"$10}}'> homo_sapiens.GRCm37.75.rrna.interval_list

